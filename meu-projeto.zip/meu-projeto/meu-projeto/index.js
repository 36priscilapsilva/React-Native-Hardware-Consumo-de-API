const express = require('express');
const app = express();
const PORT = 3000;

// Rota simples
app.get('/', (req, res) => {
  res.send('API está funcionando!');
});

// Inicializar o servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
